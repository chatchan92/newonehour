﻿# onehour

作者： 陈夏力作 和 李艳 

傻逼-3-

http://www.chanfocus.com/

登陆系统

主页面：
“是否进入时间足迹”与时间足迹联动
“是否进入时间足迹”屏蔽nav
登录系统与时间足迹结合


禅境花园：
左侧菜单随分辨率变化


YAN LI
Chen Xia
